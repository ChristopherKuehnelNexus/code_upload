using DevOpsWebApp.Pages;

namespace DevOpsWebAppTest
{
    public class IndexPageTests
    {
        [Fact]
        public void OnGet_Test()
        {
            //arrange
            var pageModel = new IndexModel();

            //act
            pageModel.OnGet();

            //assert
            Assert.NotNull(pageModel);
        }
    }
}