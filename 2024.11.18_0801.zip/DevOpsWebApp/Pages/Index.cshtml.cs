using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DevOpsWebApp.Pages
{
    public class IndexModel : PageModel
    {
        public IndexModel()
        {
        }

        public void OnGet()
        {

        }
    }
}
