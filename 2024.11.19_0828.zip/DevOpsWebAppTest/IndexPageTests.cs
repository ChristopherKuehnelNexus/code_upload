using DevOpsWebApp.Pages;

namespace DevOpsWebAppTest
{
    public class IndexPageTests
    {
        [Fact]
        public void OnGet_Test()
        {
            //arrange
            var pageModel = new IndexModel();

            //act
            pageModel.OnGet();

            //assert
            Assert.NotNull(pageModel);
        }

        [Fact]
        public void Addition_Test()
        {
            // arrange
            var value = 10;
            var expected = 11;

            // act
            value++;

            // assert
            Assert.Equal(expected, value);
        }
    }
}